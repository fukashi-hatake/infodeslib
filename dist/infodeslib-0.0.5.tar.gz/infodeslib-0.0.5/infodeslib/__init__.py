"""A Python library for Dynamic Ensemble Selection.
"""

# list of all modules available in the library
__all__ = ['des']

__version__ = '0.0.4'
